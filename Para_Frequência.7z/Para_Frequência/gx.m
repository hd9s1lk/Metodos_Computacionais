function [y] = gx(x)
    y=exp(x)/3;
end
    