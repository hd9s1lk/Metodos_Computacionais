function [y] = erro(a,b)
    erroFinal = a - b;
    fprintf("Erro: %f\n", erroFinal);
