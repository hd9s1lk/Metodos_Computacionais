function [y] = dfunc(x)
%escrever uma funcao para derivá-la
    y = cos(x)-2;
end