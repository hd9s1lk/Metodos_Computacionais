function y = Ex2Bissecao(x)
    y=exp(-x)-x
end
