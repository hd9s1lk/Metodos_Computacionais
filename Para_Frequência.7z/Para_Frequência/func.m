function [y] = func(x)
%funcao base
    y = sin(x) +1 -(2*x);
end